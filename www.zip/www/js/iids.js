'use strict';

define([
  'jquery',
  'jquery-ui',
  'bootstrap',
  'ge/iids-navbar'
], function($) {

  // Kickoff jQuery UI sortable
  $('.row').sortable({
    handle:          '.module-header',
    helper:          'clone',
    items:           '.draggable',
    forceHelperSize: true,
    revert:          200,
    tolerance:       'pointer'
  });

  // Register tooltips.
  $('[rel=tooltip]').tooltip();

  // Register popovers.
  $('[rel=popover]').popover();

});
