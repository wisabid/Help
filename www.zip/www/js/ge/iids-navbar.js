'use strict';

define([
  'jquery',
  'bootstrap/bootstrap-collapse',
  'bootstrap/bootstrap-tooltip',
  'bootstrap/bootstrap-transition'
],

function($) {

  /* NAVBAR PUBLIC CLASS DEFINITION
  * =============================== */

  var Navbar = function(element, options) {
    this.init('navbar', element, options);
  };

  Navbar.prototype = {

    constructor: Navbar,

    init: function(type, element, options) {
      this.type = type;
      this.$element = $(element);
      this.$primaryNav = this.$element.find('.primary-navbar');
      this.$masthead = this.$element.find('.masthead');
      this.$userUtils = this.$element.find('.user-utilities-and-search-container');
      this.$userUtilsDropdown = this.$element.find('.user-utilities .dropdown-menu');
      this.$notifications = this.$element.find('.notifications');
      this.$notificationsDropdown = this.$element.find('.notifications .dropdown-menu');
      this.$megaDropdown = this.$element.find('.mega-dropdown');
      this.options = this.getOptions(options);

      // navbar tooltips
      $('.navbar a[rel="tooltip"]').tooltip({ placement: 'bottom' });

      // extend mega dropdowns
      this.extendMegaDropdowns();

      // listeners
      // Attach to collapse event.
      this.$primaryNav.on('show', $.proxy(function() {
        this.$masthead.find('.btn-collapse').addClass('in');
        this.resize();
      }, this));

      // Disable overflow so that our dropdowns will work correctly.
      this.$primaryNav.on('shown', $.proxy(function() {
        this.$primaryNav.css('overflow', 'visible');
      }, this));

      // Set the overflow back to hide so it will collapse properly.
      this.$primaryNav.on('hide', $.proxy(function() {
        this.$masthead.find('.btn-collapse').removeClass('in');
        this.$primaryNav.css('overflow', 'hidden');
      }, this));

      // Hide the fake faceted dropdown when the search field is blurred (loses focus).
      this.$element.find('.search-query').on('blur', function () {
        $(this).parents('.navbar-search').removeClass('open');
      });

      // Reposition elements on window resize
      $(window).on('resize', $.proxy(this.resize, this));
      this.resize();
    },

    getOptions: function(options) {
      options = $.extend({}, $.fn[this.type].defaults, options, this.$element.data());
      return options;
    },

    resize: function() {
      // Move the user utilities and search container.
      if (!this.options.excludes.tablet && $(window).width() <= 979) {
        // From masthead to primary-navbar.
        if (this.$masthead.find(this.$userUtils).length) {
          this.$primaryNav.find('.container').prepend(this.$userUtils);
          this.$userUtilsDropdown.addClass('pull-left').removeClass('pull-right');
        }
      } else {
        // From primary-navbar to masthead.
        if (this.$primaryNav.find(this.$userUtils)) {
          this.$masthead.find('.container').append(this.$userUtils);
          this.$userUtilsDropdown.addClass('pull-right').removeClass('pull-left');
        }
      }

      // Move the notifications container.
      if (!this.options.excludes.phone && $(window).width() <= 480) {
        // Move from masthead to primary-navbar.
        if (this.$masthead.find(this.$notifications).length) {
          this.$primaryNav.find('.container').prepend(this.$notifications);
          this.$notificationsDropdown.addClass('pull-left').removeClass('pull-right');
          this.$megaDropdown.css('position', 'static');
        }
      } else {
        // Move from primary-navbar to masthead.
        if (this.$primaryNav.find(this.$notifications).length) {
          this.$masthead.find('.container').append(this.$notifications);
          this.$notificationsDropdown.addClass('pull-right').removeClass('pull-left');
          this.$megaDropdown.css('position', 'absolute');
        }
      }

      // Resize mega-dropdowns
      this.$megaDropdown.each(function() {
        $(this).css({ left: 0, width: ($(this).parents('.primary-navbar .container').width()) });
      });
    },

    extendMegaDropdowns: function() {
      // Make "mega" dropdowns extend the full width of the screen.
      this.$megaDropdown.each( function() {
        var $this = $(this);
        var $toggle = $this.prev('.dropdown-toggle');
        var $arrow = $('<span class="mega-dropdown-arrow"></span>');

        $this
          .css({ left: 0, width: ( $this.parents('.primary-navbar .container').width() ) })
          .parent('.btn-group').css('position','static')
          .append($arrow);

        $arrow.css('left',
          $toggle.parent().position().left + $toggle.outerWidth() / 2);
      });
    },

  };

  /* NAVBAR PLUGIN DEFINITION
  * ========================= */

  $.fn.navbar = function(option) {
    return this.each(function () {
      var $this = $(this),
          data = $this.data('navbar'),
          options = typeof option === 'object' && option;

      if (!data) $this.data('navbar', (data = new Navbar(this, options)));
      if (typeof option === 'string') data[option]();
    });
  };

  $.fn.navbar.Constructor = Navbar;

  $.fn.navbar.defaults = {
    excludes: {
      tablet: false,
      phone: false
    }
  };

  // Kickoff the navbar on page load.
  // If you wanted to disable responsive breakpoints you
  // would need to remove this snippet and call it yourself.
  // This snippet will be removed in future versions of the IIDS

  $(function () {
    $('.navbar').navbar();
  });

});
