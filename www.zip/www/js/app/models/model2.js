define(['./basicModel'], function (BasicModel) {
    var model2 = new BasicModel('This is the title for Page 2', '100%');
    return model2;
});
