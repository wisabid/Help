define(['./basicModel'], function (BasicModel) {
    var model1 = new BasicModel('This is the title for Page 1', '50%');
    return model1;
});
